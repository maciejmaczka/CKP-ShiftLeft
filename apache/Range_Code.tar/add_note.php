<html>

<body>
<center>
<img src="jpg/logo.jpg" width="150" height="71" alt="">
</center>


<br/>


<?php

$get_login = $_COOKIE["user"];
$get_note = $_GET["note"];

ini_set('display_errors', 'On');
error_reporting(-1);
include 'check_auth.php';


if (!$link = mysqli_connect('range_db', 'radware', 'clico123!')) {
    echo 'Sorry, problem with database (stage 1)';
    exit;
}


if (!mysqli_select_db( $link, 'radware_DB')) {
    echo 'Sorry, problem with database (stage 2)';
    exit;
}




$sql = "INSERT INTO `radware_DB`.`posts` (`login`, `text`) VALUES ('".$get_login."', '".$get_note."');";


if ($link->query($sql) === TRUE) {
    echo "Note added. Auto redirect in 5 seconds";
    header( "refresh:5;url=main.php" );
} else {
    echo "Error: " . $sql . "<br>" . $link->error;
}

$link->close();




?>


