<?php

$get_login = $_COOKIE["user"];


echo " <p align=\"right\"> ";
echo "Welcome:  " ;
echo $get_login;
echo " </p> ";


if (!$link = mysqli_connect('range_db', 'radware', 'clico123!')) {
    echo 'Sorry, problem with database (stage 1)';
    exit;
}


if (!mysqli_select_db( $link, 'radware_DB')) {
    echo 'Sorry, problem with database (stage 2)';
    exit;
}

$sql = "SELECT login from app_logins where login = '".$get_login."' ; ";


$result = mysqli_query( $link, $sql);


if (mysqli_num_rows($result) == 0){
	

   if (isset($_COOKIE['user'])) {
    unset($_COOKIE['user']); 
    setcookie('user', null, -1, '/'); 
   
}
   
    
    header('Location: login.php'); 
    exit;

}



?>