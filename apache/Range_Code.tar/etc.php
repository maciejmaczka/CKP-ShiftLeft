<html>

<body>
<center>
<img src="jpg/logo.jpg" width="150" height="71" alt="">
</center>


<br/>


<?php

include 'check_auth.php';


?>


<center>
<h1> Select action: </h1>

<h2>  <a href="main.php">Notes</a> | <a href="acc.php">Account</a> | <a href="trans.php">Transactions</a> | <a href="etc.php">etc</a> | <a href="login.php">Logout</a> </h2> 

</center>


<center>

<form action="upload.php" method="post" enctype="multipart/form-data">
    Select image to upload:
    <input type="file" name="fileToUpload" id="fileToUpload">
    <input type="submit" value="Upload Image" name="submit">
</form>

</center>


<body>

</html>