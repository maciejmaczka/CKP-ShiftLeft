<html>

<body >

<center> <h1> Welcome to CLICO Shooting Range </h1>  
<br/>
<br/>

<img src="jpg/logo.jpg" width="300" height="142" alt="">

</center>


<br/>
<br/>

<center> <h2> Please log in  </h2> </center>



<center>
 <form action="login.php" method="post">
  User: <input type="text" name="login">  <br/><br/>
  Pass: <input type="password" name="password"> <br/><br/>
  <input type="submit" value="Login">
</form> 
</center>




<?php

   if (isset($_COOKIE['user'])) {
    unset($_COOKIE['user']); 
    setcookie('user', null, -1, '/'); 
   
}
   
/*
ini_set('display_errors', 'On');
error_reporting(-1);
*/

$get_login = $_POST['login'];
$get_pass = $_POST['password'];


if (strlen($get_login) == 0)
{
	exit;

}

if (strlen($get_pass) == 0)
{
        exit;

}




if (!$link = mysqli_connect('range_db', 'radware', 'clico123!')) {
    echo 'Sorry, problem with database (stage 1)';
    exit;
}


if (!mysqli_select_db( $link, 'radware_DB')) {
    echo 'Sorry, problem with database (stage 2)';
    exit;
}

$sql = "SELECT login from app_logins where login = '".$get_login."' and pass = '".$get_pass."' ; ";




$result = mysqli_query( $link, $sql);


if (!$result) {
    echo "Sorry, problem with database (stage 3)\n";
    echo 'Blad MySQL:'  ;
    echo $sql;
    exit;
}

if (mysqli_num_rows($result) == 0){
	
    echo "<center> Bad username or password </center> <br/>";
    exit;

}



	while ($row = mysqli_fetch_assoc($result)) {

		echo "<center> You are now logged as: ";	
		echo $row['login'];
        	echo ' </center> <br/>';	
	}

echo "<center> You will be redirected in 2 seconds. If not go to <a href=\"main.php\">main page</a>  </center>";


setcookie("user", $get_login,  time() + (86400 * 30),"/" );

header( "refresh:2;url=main.php" );
/*
header('Location: main.php'); 
*/

?>



</body>


</html>

