<html>

<body>
<center>
<img src="jpg/logo.jpg" width="150" height="71" alt="">
</center>


<br/>


<?php

include 'check_auth.php';


?>


<center>
<h1> Select action: </h1>

<h2>  <a href="main.php">Notes</a> | <a href="acc.php">Account</a> | <a href="trans.php">Transactions</a> | <a href="etc.php">etc</a> | <a href="login.php">Logout</a> </h2> 

</center>





<br/>

<center>
<b> Add note  </b>

<br/>

      <form action = "add_note.php" method = "get">
        <br>


        
         <textarea rows = "5" cols = "60" name = "note">
Place your note here...
         </textarea><br>
         <input type = "submit" value = "submit" />
      </form>
      

<br/>
<br/>
<br/>
<br/>

<b> Your notes: </b> 
<br/>
<br/>
<br/>


<?php
ini_set('display_errors', 'On');
error_reporting(-1);
$get_login = $_COOKIE["user"];


if (!$link = mysqli_connect('range_db', 'radware', 'clico123!')) {
    echo 'Sorry, problem with database (stage 1)';
    exit;
}


if (!mysqli_select_db( $link, 'radware_DB')) {
    echo 'Sorry, problem with database (stage 2)';
    exit;
}

$sql = "SELECT * from posts where login = '$get_login' ; ";



$result = mysqli_query( $link, $sql);


if (!$result) {
    echo "Sorry, problem with database (stage 3)\n";
    echo 'Blad MySQL:'  ;
    echo $sql;
    exit;
}

if (mysqli_num_rows($result) == 0){
	
    echo "<center> Nothing to display </center> <br/>";
    exit;

}


echo "<table border='0' width = '800' > ";

	while ($row = mysqli_fetch_assoc($result)) {

		echo "<tr>";
		echo "<td>";
		echo $row['id'];
		echo "</td>";
		echo "<td>";
		echo $row['text'];
		echo "</td>";
      echo '</tr>';	
	}

echo "</table>";

?>


 </center>


</html>

</body>