<html>
<body>

<center> <h1> Welcome to CLICO Shooting Range </h1>  
<br/>
<br/>

<img src="jpg/logo.jpg" width="300" height="142" alt="">





</center>


<?php

unset($_COOKIE['user']); 
setcookie('user', null, -1, '/'); 



header( "refresh:2;url=main.php" );

?>



</body>
</html>
