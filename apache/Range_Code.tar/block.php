<html>


<body>
<h1>
Your request was blocked! Sorry...
</h1>



<?php

$get_transid = $_GET['_event_transid'];


$get_clientip = $_GET['_event_clientip'];


$get_clientport = $_GET['_event_clientport'];


$get_attackname = $_GET['_event_attackname'];



$get_threatcategory = $_GET['_event_threatcategory'];


echo "Transaction ID: ";
echo $get_transid  ;
echo "<br/>";
echo "<br/>";

echo "Your IP: ";
echo $get_clientip  ;
echo "<br/>";
echo "<br/>";


echo "Your port: ";
echo $get_clientport  ;
echo "<br/>";
echo "<br/>";


echo "Violation: ";
echo $get_attackname  ;
echo "<br/>";
echo "<br/>";

echo "Violation Category: ";
echo $get_threatcategory  ;
echo "<br/>";
echo "<br/>";



?>


</body>


</html>